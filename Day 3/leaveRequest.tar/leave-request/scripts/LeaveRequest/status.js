var lastUserTask1 = $.usertasks.usertask2.last;
if(lastUserTask1 === 'approved'){
	$.context.status = 'the leave was approved';
}else{
	$.context.status = 'the leave was rejected';
}
