var price = parseFloat($.context.response.d.Price);

if (price > 100) {
	$.context.autoApprove = false;
} else {
	$.context.autoApprove = true;
}